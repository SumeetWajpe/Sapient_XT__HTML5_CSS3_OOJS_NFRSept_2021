function Fulltime() {
  this.salary = 100000;
}

function Contractor() {
  this.salary = 70000;
}

function Parttime() {
  this.dailyWages = 10000;
}

function Freelancer() {
  this.hourlyWages = 5000;
}

export default function EmployeeFactory(type) {
  let emp;
  if (type === "fulltime") {
    emp = new Fulltime();
  } else if (type === "parttime") {
    emp = new Parttime();
  } else if (type === "contractor") {
    emp = new Contractor();
  } else if (type === "freelance") {
    emp = new Freelancer();
  }

  emp.type = type;
  return emp;
}
