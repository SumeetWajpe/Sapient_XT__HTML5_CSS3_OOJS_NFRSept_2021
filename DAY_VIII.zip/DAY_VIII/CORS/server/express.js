const express = require("express");
const path = require("path");
var cors = require("cors");
var app = express();

let courses = require("./models/course.model");
app.use(cors());

app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());
app.get("/", (req, res) => res.sendFile("Courses.html", { root: __dirname }));
app.get("/courses", (req, res) => {
  // will come from db
  res.json(courses);
});

app.post("/newcourse", (req, res) => {
  let newCourseToBeAdded = req.body;
  // add newcourse to array
  // immutability -> courses = [...courses,newCourseToBeAdded]
  // added to db
  courses.push(newCourseToBeAdded);
  res.json({ status: "success", title: newCourseToBeAdded.title });
});

app.delete("/courses/:id", (req, res) => {
  let theCourseId = +req.params.id;
  let index = courses.findIndex((course) => course.id === theCourseId);
  let title = courses[index].title;
  courses.splice(index, 1);
  res.json({ status: "success", title });
});
app.listen(5000, () => console.log("Server running at 5000 !"));
