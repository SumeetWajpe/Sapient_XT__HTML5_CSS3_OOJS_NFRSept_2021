let x = 10;

export var Add = function (largerVarX, largeVarY) {
  return largerVarX + largeVarY;
};

export function Emp() {
  this.salary = 100000;
  setTimeout(() => console.log(this.salary), 2000);
}
