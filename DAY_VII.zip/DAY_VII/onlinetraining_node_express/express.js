const express = require("express");
const path = require("path");
const app = express();
let courses = require("./models/course.model");

app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());
app.get("/", (req, res) => res.sendFile("Courses.html", { root: __dirname }));
app.get("/courses", (req, res) => {
  // will come from db
  res.json(courses);
});

app.post("/newcourse", (req, res) => {
  let newCourseToBeAdded = req.body;
  // add newcourse to array
  // immutability -> courses = [...courses,newCourseToBeAdded]
  // added to db
  courses.push(newCourseToBeAdded);
  res.end("success");
});
app.listen(5000, () => console.log("Server running at 5000 !"));
