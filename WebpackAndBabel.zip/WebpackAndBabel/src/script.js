import { Add } from "./module";
console.log("The addition is : " + Add(20, 30));

/* These should not appear in production ! */
